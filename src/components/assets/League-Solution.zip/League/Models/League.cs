namespace League.Models
{
  public class League
  {
    public string LeagueId { get; set; }
    public string Name { get; set; }
  }
}
